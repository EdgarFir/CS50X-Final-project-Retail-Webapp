IMPORTANT: 

Enter the values ​​correctly, especially the description and the barcode because it is from them that we can track the information.

Description e.g ('Coca-Cola 33cl')
Bar code e.g ('5601234567890')

Description and bar code have a limitation between 4 and 120 characters.

Enter valid prices in cost_price, sell_price and a valid numeric number in quantity. Be sure they're higher than 0.